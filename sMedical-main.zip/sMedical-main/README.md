
# sMedical

This is a complete doctor appointment app there user can appoint a doctor.
please give a star for more projects.If it work for you please give me a star.and you can follow me for more projects. 

## Notice
Please don't change anything in firebase.if i got anything changed then i will remove firebase permissions.

## Installation
Please don't change any thing with firebase if you want to work and update this then connect your own firebase

For run this project just clone this project and run this command in your project terminal

```bash
  flutter pub get
```
    
## Support

For support, email sagorsamadder.official@gmail.com


## Authors

- [@sagor1414](https://www.github.com/sagor1414)


## Features

- Light/dark mode toggle
- Live previews
- Fullscreen mode
- Cross platform
- responseive ui


## State mannagement
    for state mannagement wee use GETX
## Backend
    for auth and storeing data we use firebase as a backend service
## Screenshots
Home page
![Home page Screenshot](https://github.com/sagor1414/sMedical/blob/main/assets/Screenshot_1701920056.png?raw=true)

Category page

![category page](https://github.com/sagor1414/sMedical/blob/main/assets/images/Screenshot_1701920078.png?raw=true)

Some others

![others](https://github.com/sagor1414/sMedical/blob/main/assets/images/Screenshot_1701920083.png?raw=true)

![others](https://github.com/sagor1414/sMedical/blob/main/assets/images/Screenshot_1701920088.png?raw=true)

![others](https://github.com/sagor1414/sMedical/blob/main/assets/images/Screenshot_1701920095.png?raw=true)

![others](https://github.com/sagor1414/sMedical/blob/main/assets/images/Screenshot_1701920099.png?raw=true)

![others](https://github.com/sagor1414/sMedical/blob/main/assets/images/Screenshot_1701920104.png?raw=true)

![other](https://github.com/sagor1414/sMedical/blob/main/assets/images/Screenshot_1701920115.png?raw=true)
## License
[sagor1414](https://github.com/sagor1414)


## 🚀 About Me
I'm a full stack developer...

