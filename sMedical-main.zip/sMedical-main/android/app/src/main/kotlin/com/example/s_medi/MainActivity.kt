package com.example.s_medi

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
