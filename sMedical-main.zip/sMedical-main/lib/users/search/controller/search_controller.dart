import 'package:s_medi/general/consts/consts.dart';

class DocSearchController extends GetxController {
  var searchQueryController = TextEditingController();
}
