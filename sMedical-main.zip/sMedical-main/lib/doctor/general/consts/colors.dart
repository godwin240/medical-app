import 'package:flutter/material.dart';

class AppColors {
  static Color primeryColor = const Color(0xff4B2EAD),
      greenColor = const Color(0xff88D008),
      bgColor = const Color(0xffF5F5F5),
      whiteColor = Colors.white,
      textcolor = Colors.black,
      redcolor = Colors.red,
      bgDarkColor = const Color(0xffECECEC);
}
